#!/usr/bin/env python3
"""
CSS Fix Script for resume index.html
Uses letter-only placeholders to avoid write-tool number corruption.
Replace placeholders with actual values at runtime.
"""
import re
import sys

PLACEHOLDER_MAP = {
    'ZEROPX': '0',
    'ONEPX': '1',
    'TWOPX': '2',
    'THREEPX': '3',
    'FOURPX': '4',
    'FIVEPX': '5',
    'SIXPX': '6',
    'SEVENPX': '7',
    'EIGHTPX': '8',
    'NINEPX': '9',
    'TENPX': '10',
    'TWELVEPX': '12px',
    'SIXTEENPX': '16px',
    'TWENTYFOURPX': '24px',
    'THIRTYPX': '30px',
    'THIRTYSIXPX': '36px',
    'FORTYEPX': '40px',
    'FORTYEIGHTPX': '48px',
    'SIXTYPX': '60px',
    'SEVENTYTWOPX': '72px',
    'EIGHTYPPX': '80px',
    'ONETWENTYPX': '120px',
    'ONETHIRTYPPX': '130px',
    'TWOHUNDREDPX': '200px',
    'THREEHUNDREDPX': '300px',
    'FOURHUNDREDPX': '400px',
    'SIXHUNDREDPX': '600px',
    'ELEVENHUNDREDPX': '1100px',
    # Transition durations
    'POINTONESS': '0.1s',
    'POINTTHREESS': '0.3s',
    'POINTFOURSS': '0.4s',
    'POINTNINESS': '0.9s',
    'ONES': '1s',
    'TWOS': '2s',
    'THREES': '3s',
    'FOURS': '4s',
    'EIGHTS': '8s',
    'TENS': '10s',
    # Z-index
    'ZINDEXTWO': '2',
    'ZINDEXONE': '1',
    'ZINDEXNINE': '999',
    'ZINDEXTEN': '1000',
    # Other
    'HALF': '0.5',
    'POINTONE': '0.1',
    'POINTTWELVE': '0.12',
    'POINTFIFTEEN': '0.15',
    'POINTTHIRTYFIVE': '0.35',
    'POINTFORTY': '0.499',
    'POINTSIXTY': '0.6',
    'POINTSEVENTY': '0.7',
    'POINTEIGHTY': '0.8',
    'FIFTY': '50',
    'ONEHUNDRED': '100',
    'ONEFIFTY': '150',
    'TWOHUNDRED': '200',
    'THREEHUNDRED': '300',
    'NINETYTWO': '1920',
    # border-radius
    'RADIUSFIFTY': '50%',
    'RADIUSSIXTEEN': '16px',
    'RADIUSTWELVE': '12px',
    'RADIUSSIX': '6px',
    'RADIUSTWENTY': '20px',
    # font-size
    'FONTSIZEFOURTEEN': '14px',
    'FONTSIZEEIGHTEEN': '18px',
    'FONTSIZETWENTY': '20px',
    'FONTSIZETWENTYFOUR': '24px',
    'FONTSIZETHIRTYSIX': '36px',
    'FONTSIZEFORTYEIGHT': '48px',
    'FONTSIZETHIRTEEN': '13px',
    'FONTSIZEFIFTEEN': '15px',
}

HTML_FILE = r'C:\张泽昊\deepseekharness test\resume_site\templates\index.html'

# Build replacement patterns
def fix_css():
    with open(HTML_FILE, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original = content
    
    # Fix placeholder values
    for key, val in PLACEHOLDER_MAP.items():
        content = content.replace(key, val)
    
    # Write back if changed
    if content != original:
        with open(HTML_FILE, 'w', encoding='utf-8') as f:
            f.write(content)
        print("CSS fixed successfully")
    else:
        print("No changes needed")
    
    return content

if __name__ == '__main__':
    fix_css()