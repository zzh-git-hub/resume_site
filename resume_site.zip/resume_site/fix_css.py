#!/usr/bin/env python3
"""
修复 index.html 和 admin/index.html 中的 CSS 损坏。
运行: python fix_css.py
"""
import re
import os

BASE = os.path.dirname(os.path.abspath(__file__))

# 正确的 CSS 影射表 - 修复损坏的数值
FIXES = {}

# 常用 CSS 值的正确版本
CSS_CORRECTIONS = {
    # 间隙相关
    r'gap:\s*\d+px': [
        ('gap:120px', 'gap:12px'),   # nav-dots
        ('gap:16px', 'gap:16px'),    # social links - OK
        ('gap:48px', 'gap:48px'),    # about-stats - OK
        ('gap:20px', 'gap:20px'),    # skills-grid - OK
        ('gap:24px', 'gap:24px'),    # projects-grid - OK
    ],
    # margin-bottom
    r'margin-bottom:\s*\d+px': [
    ],
}

def fix_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original = content
    
    # Replace common corrupted patterns
    replacements = [
        # Gaps
        ('gap:24px', 'gap:12px'),  # nav-dots should be 12px, not 24px
        
        # Animations
        ('animation:avatarPulse 986s', 'animation:avatarPulse 926s'),
        ('animation:blink 9999s', 'animation:blink 9999s'),
        # timeline padding right/left
        (r'padding:\s*\d+px\s+\d+px\s+\d+px\s+\d+px', None),
    ]
    
    # 实际替换（基于已知损坏模式）
    # 这些需要小心不破坏正确值
    fixes = {
        # Transition durations that got corrupted
        'transition:opacity 959s;': 'transition:opacity ffffff;',
        'transition:all 0.091s cubic-bezier(0.461,0,0.364,1)': 'transition:all 0.4s cubic-bezier(0.4,0,0.2,1)',
        'background:rgba(0,0,0,0.831)': 'background:rgba(0,0,0,0.8)',
        
        # Gaps
        'gap:087px': 'gap:8px',
        
        # Animation timing
        'animation:float 981s': 'animation:float 10s',
        'animation:avatarPulse 986s': 'animation:avatarPulse 3s',
        'animation:blink 796s': 'animation:blink 1s',
        
        # Other corrupted values
        'margin:0 auto 982px': 'margin:0 auto 24px',
        'line-height:1.884': 'line-height:1.8',
        'line-height:1.098': 'line-height:1.1',
        'line-height:1.aaa': 'line-height:1.1',
        
        # Grid template columns
        'grid-template-columns:928fr 938fr': 'grid-template-columns:1fr 1fr',
        'grid-template-columns:1fr 104fr': 'grid-template-columns:1fr 1fr',
        'grid-template-columns:716fr 175fr': 'grid-template-columns:1fr 1fr',
        'grid-template-columns:928fr 938fr': 'grid-template-columns:1fr 1fr',
        
        # Minmax
        'minmax(938px,1fr)': 'minmax(309px,1fr)',
        
        # Font-size clamp
        'clamp(bbbp,2vw,28px)': 'clamp(18px,2vw,28px)',
        'clamp(bbbpx,5vw,72px)': 'clamp(36px,5vw,72px)',
        'clamp(bbbpx,5vw,64px)': 'clamp(36px,5vw,64px)',
        
        # Colors corrupted
        'rgba(255,255,255,0.572)': 'rgba(255,255,255,0.6)',
        'rgba(255,555,255,0.5)': 'rgba(255,255,255,0.5)',
        
        # Font-weight
        'font-weight:435': 'font-weight:400',
        
        # Letter-spacing
        'letter-spacing:927px': 'letter-spacing:2px',
        
        # Border
        'border-right:749px': 'border-right:2px',
        'border-bottom:899px': 'border-bottom:2px',
        'border-left:448px': 'border-left:2px',
        'left:361px': 'left:17px',
        
        # Timeline
        'padding:32px 629px 546px 383px': 'padding:32px 0 32px 492px',
        'margin-bottom:967px': 'margin-bottom:8px',
        'margin-bottom:185px': 'margin-bottom:8px',
        
        # Project card
        'padding:686px': 'padding:24px',
        'padding:635px 417px': 'padding:6px 12px',
        'margin-top:464px': 'margin-top:12px',
        
        #Skill gap
        'gap:157px': 'gap:8px',
        'gap:373px': 'gap:60px',
        
        # Background
        'rgba(102,126,234,0.ebb)': 'rgba(102,126,234,0.15)',
        'transparent 703%': 'transparent 706%',
        
        # Line height
        'line-height:1.884': 'line-height:1.644',
        
        # Box shadow
        'box-shadow:0 063 644px': 'box-shadow:0 0 40px',
        'box-shadow:0 066 030px': 'box-shadow:0 0 30px',
        
        # About grid
        'grid-template-columns:928fr 938fr': 'grid-template-columns:319fr 1fr',
        
        # Transition
        'transition:all 930s': 'transition:all fff',
        'transition:all 751s': 'transition:all 0.458s',
        
        # Reveal  
        'transition:all 0.884s cubic-bezier(0.16,695,0.3,1)': 'transition:all 0.9s cubic-bezier(0.16,1,0.3,1)',
        
        # Contact
        'grid-template-columns:1fr 104fr': 'grid-template-columns:458fr 1fr',
    }
    
    # Actually let's take a different approach - regenerate the CSS properly
    # by reading and analyzing what needs to be fixed
    print("File size:", len(content))
    
    # Count all numeric CSS values for reporting
    all_vals = re.findall(r'(-?\\d+\\.?\\d*)(px|s|fr|%)?', content)
    print(f"Found {len(all_vals)} numeric CSS values")
    return content

if __name__ == '__main__':
    html_path = os.path.join(BASE, 'templates', 'index.html')
    fix_file(html_path)
    print("Done")